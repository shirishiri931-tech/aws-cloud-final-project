import json
import boto3
import uuid
from datetime import datetime, timezone
from decimal import Decimal

VERSION_TYPE_TO_STATUS = {
    'Submitted': 'Ready for Review',
    'Reviewed': 'Under Review',
    'Revised': 'Ready for Review'
}

dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
s3 = boto3.client('s3', region_name='us-east-1')
documents_table = dynamodb.Table('DocumentFlow-Documents')
history_table = dynamodb.Table('DocumentFlow-VersionHistory')

BUCKET_NAME = 'documentflow-files-217019990923'
ses = boto3.client('ses', region_name='us-east-1')
SENDER_EMAIL = 'shirishiri931@gmail.com'

def send_notification(to_email, subject, message):
    if not to_email:
        return
    try:
        ses.send_email(
            Source=SENDER_EMAIL,
            Destination={'ToAddresses': [to_email]},
            Message={'Subject': {'Data': subject}, 'Body': {'Text': {'Data': message}}}
        )
    except Exception as e:
        print(f"Email error: {str(e)}")

def lambda_handler(event, context):
    try:
        body = json.loads(event.get('body', '{}'))
        document_id = event.get('pathParameters', {}).get('id')
        
        if not document_id:
            return {
                'statusCode': 400,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'error': 'Missing document ID'})
            }
        
        response = documents_table.get_item(Key={'documentId': document_id})
        document = response.get('Item')
        
        if not document:
            return {
                'statusCode': 404,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'error': 'Document not found'})
            }
        
        new_version = int(document.get('currentVersion', 0)) + 1
        file_name = body.get('fileName', 'document')
        version_type = body.get('versionType', 'Submitted')
        status_at_upload = body.get('statusAtUpload', 'In Progress')

        if not file_name or not str(file_name).strip():
            return {
                'statusCode': 400,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'error': 'fileName must be a non-empty string'})
            }

        new_status = VERSION_TYPE_TO_STATUS.get(version_type, 'In Progress')
        s3_key = f"documents/{document_id}/versions/v{new_version}/{file_name}"
        
        presigned_url = s3.generate_presigned_url(
            'put_object',
            Params={'Bucket': BUCKET_NAME, 'Key': s3_key, 'ContentType': 'application/octet-stream'},
            ExpiresIn=3600
        )
        
        now = datetime.now(timezone.utc).isoformat()

        documents_table.update_item(
            Key={'documentId': document_id},
            UpdateExpression='SET currentVersion = :v, s3Key = :s, lastUpdated = :t, #st = :status, currentFileName = :fn',
            ExpressionAttributeValues={
                ':v': Decimal(new_version),
                ':s': s3_key,
                ':t': now,
                ':status': new_status,
                ':fn': file_name
            },
            ExpressionAttributeNames={'#st': 'status'}
        )
        
        history_table.put_item(Item={
            'documentId': document_id,
            'versionNumber': Decimal(new_version),
            's3Key': s3_key,
            'uploadedBy': body.get('uploadedBy', 'unknown'),
            'uploadedAt': now,
            'fileName': file_name,
            'versionType': version_type,
            'statusAtUpload': status_at_upload
        })

        reviewer_email = document.get('reviewerEmail', '')
        if version_type == 'Submitted' and reviewer_email:
            subject = f"DocumentFlow - Document Ready for Review: {document.get('title', '')}"
            message = f"""A document has been submitted and is ready for your review.

Document: {document.get('title', '')}
Project: {document.get('projectName', '')}
Version: {new_version}

Please log in to DocumentFlow Cloud to review the document."""
            send_notification(reviewer_email, subject, message)

        return {
            'statusCode': 200,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({
                'message': 'Version created successfully',
                'versionNumber': new_version,
                'uploadUrl': presigned_url,
                's3Key': s3_key
            })
        }
    
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': 'Internal server error'})
        }